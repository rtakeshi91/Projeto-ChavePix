package com.project.ApiPix;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiPixApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiPixApplication.class, args);

	}

}
