package com.project.ApiPix.Domain;

public enum TipoChave {
    celular,
    email,
    cpf,
    cnpj,
    aleatorio
}
