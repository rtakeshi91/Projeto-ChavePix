package com.project.ApiPix.Domain;

public enum TipoConta {
    contacorrente,
    contapoupanca
}
