package com.project.ApiPix.Record;

import org.junit.jupiter.api.Test;

class DadosCadastroChavePixTest {

    @Test
    void tipoChave() {
    }

    @Test
    void valorChave() {
    }

    @Test
    void tipoConta() {
    }

    @Test
    void numeroAgencia() {
    }

    @Test
    void numeroConta() {
    }

    @Test
    void nome() {
    }

    @Test
    void sobrenome() {
    }
}