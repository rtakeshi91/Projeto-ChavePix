package com.project.ApiPix;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiPixApplicationTests {

	@Test
	void contextLoads() {
	}

}
